
var fileDuration;

var startTime;
var endTime;
var duration;
var randomMult;
var mode;
var manualValue;
var sizeWin;
var startScrub = 1;
var endScrub = 1;
var currentStep = 1;

function grainCalc() {

	var randOne = randy(0, fileDuration);
	var randTwo = randy(0, fileDuration);

	startTime = Math.min(randOne, randTwo);
	endTime = Math.max (randOne, randTwo);

	switch(mode) {
		case 1:
			duration = endTime - startTime;
			break;
		case 2:
			duration = (endTime - startTime) * 0.5;
			break;
		case 3:
			duration = (endTime - startTime) * 0.25;
			break;
		case 4:
			duration = (endTime - startTime) * 2;
			break;
		case 5: 
			duration = (endTime - startTime) * 4;
			break; 
		case 6: 
			randomMult = Math.pow(2,((Math.floor(randy(0, 5)))-2)); 
			duration = (endTime - startTime) * randomMult;
			break;
		case 7: 
			duration = (endTime - startTime) * randy(0, 3);
			break;
		case 8: 
			duration = (endTime - startTime) * manualValue;
			break;
		case 9:
			startTime = startScrub*randy(startTime, endTime);
			endTime = (startTime + sizeWin)*endScrub;
			duration = sizeWin;
			break;
		case 10:
			startTime = randy(startTime, endTime);
			endTime = (startTime + sizeWin);
			duration = sizeWin / currentStep;
			break;
		default:
			break; 
	}


	outlet(0, startTime, endTime, duration);

}

function randy (min, max) {

	return (Math.random() * max) + min;

}
